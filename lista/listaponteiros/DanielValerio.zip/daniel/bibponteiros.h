int* criaVet(int pos, int val);
int* criaVetAl(int n);
int** criaMat(int lin, int col, int val);
char* strCopy(char* s);
char* sub1(char* s, int inicio, int fim);
char* sub2(char* s, int indice);
int compara_int(void* a, void* b);
